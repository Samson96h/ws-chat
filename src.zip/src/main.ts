import { NestFactory } from '@nestjs/core';
import { Logger } from '@nestjs/common';

import { CustomWsAdapter } from './modules/ws-adapter';
import { AppModule } from './app.module';


async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const logger = new Logger('Bootstrap');

  app.useWebSocketAdapter(new CustomWsAdapter(app));

  const port = 4001;
  await app.listen(port);

  logger.log(`         App running on port ${port}`);
}

bootstrap();
