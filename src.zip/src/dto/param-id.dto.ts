import { IsNotEmpty } from "class-validator";


export class ParamIdDTO {
    @IsNotEmpty()
    id: number;
}