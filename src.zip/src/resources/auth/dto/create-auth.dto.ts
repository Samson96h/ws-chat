import { IsNotEmpty, IsPhoneNumber, IsString, MinLength } from "class-validator";


export class CreateAuthDTO {
    @IsPhoneNumber()
    phone: string;
    
    @IsNotEmpty()
    @IsString()
    @MinLength(3)
    name: string;
}
