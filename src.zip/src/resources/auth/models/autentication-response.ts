export interface IAuthEnticationResponse {
    accessToken?: string,
    code?: string,
    message?: string
}