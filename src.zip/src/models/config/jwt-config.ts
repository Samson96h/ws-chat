export interface IJWTConfig {
    tempSecret: string,
    secret: string,
    expiresIn: string,
}

