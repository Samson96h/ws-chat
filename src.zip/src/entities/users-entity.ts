import { Entity, Column, OneToMany, ManyToMany } from 'typeorm';

import { SecretCode } from './secret-code';
import { Message } from './message-entity';
import { Chat } from './chat-entity';
import { Base } from './base';


@Entity()
export class User extends Base {
  @Column()
  name: string;

  @Column({ unique: true })
  phone: string;

  @ManyToMany(() => Chat, (chat) => chat.members)
  chats: Chat[];

  @OneToMany(() => Message, (message) => message.user)
  messages: Message[];

  @OneToMany(() => SecretCode, (secretCode) => secretCode.user, { cascade: true })
  secretCodes: any;

}