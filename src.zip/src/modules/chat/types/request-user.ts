export interface IRequestUser {
    id: number
    name: string
    phone: string
    temp?: boolean
}